--
-- All SQL statements must be on a single line and end in a semicolon.
--

-- Index Your Tables Here (Optional) --
-- CREATE INDEX user_idx ON users();
-- CREATE INDEX workspace_idx ON workspace();
-- CREATE INDEX channel_idx ON channel();
-- CREATE INDEX message_idx ON message();